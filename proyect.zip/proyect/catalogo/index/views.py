from django.shortcuts import render
from django.http import JsonResponse

# Create your views here.




# Esta función responde un html llamado index
def index(request):
    # print('asdasd')
    
    return render(request, "index.html")



def busqueda(request):
    #Ir por los datos del juego solicitado
    juego = request.GET.get('texto'," ")

    # Hacer la busqueda en la base de datos  con juego




    context= {
                'espacio' : juego,
            }

    return JsonResponse(context)