
function buscar(){
    // alert('Elminmna')
    const xhr = new XMLHttpRequest();


    xhr.open("GET", "/search?texto="+document.getElementById('texto').value );
    xhr.send();
    xhr.responseType = "json"; 
    xhr.onload = () => {
    if (xhr.status==200){
    //   alert(xhr.response['espacio']);
      document.getElementById('test').value= xhr.response['espacio'];  
      document.getElementById('test').hidden = false; 
    }
    else{
      alert("Error en el servidor web")
    }
    };   
  }
  